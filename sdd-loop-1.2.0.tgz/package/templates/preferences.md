> **文件说明**：`.workflow/preferences.md` 记录跨会话沉淀的**工程偏好/惯例**（团队共享、committed）。
> - 由 reviewer 审查后 / 任务收尾时追加；子 agent 开工前读取并遵循
> - 每条注明来源引用（spec / design / changes），便于追溯与去重
> - 与 spec/需求/design 冲突时**以 spec/design 为准**——preferences 是**软约束**
> - 探索性的一次性结论写入 `.workflow/changes/`，**可复用的稳定偏好**才写入本文件

# 工程偏好 / 惯例（跨会话沉淀）

> 各区块按需保留/删除；条目格式：`- **偏好**：描述（来源：<引用>）`

## 图规范偏好

- **偏好**：出图两轨制——复杂架构图用内置 Archify（产出 JSON IR → `archify validate` 过验证门 → `render` 出 SVG 内嵌 + 归档 JSON），简单图用 Mermaid（来源：design:0001-xxx / changes:2026-08-21-xxx）
- **偏好**：Mermaid 架构图必须用 subgraph 分组、节点 ≤ 20、方向单一、禁用 ELK（来源：design:0001-xxx / changes:2026-08-21-xxx）

## 命名习惯

- **偏好**：接口路径用 kebab-case、数据库表用 snake_case（来源：...）

## 技术栈 / 框架偏好

- **偏好**：优先用 X 框架、避免 Y（来源：...）

## 代码风格

- **偏好**：错误处理用早返回（来源：...）

## 验收标准偏好

- **偏好**：每个功能必须带 happy path + 边界用例（来源：...）
